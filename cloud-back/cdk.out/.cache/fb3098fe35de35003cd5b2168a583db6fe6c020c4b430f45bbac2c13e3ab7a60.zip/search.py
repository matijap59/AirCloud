

def lambda_handler(event, context):

    #search_query = generate_all_attributes(search_params)

    return {
        "statusCode": 200,
        "body": ""
    }